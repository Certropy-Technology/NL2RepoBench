import type * as core from "./core.js";
import type { SomeType } from "./schemas.js";
/** Sentinel value returned by the compiled fast path when validation fails. Internal. */
export declare const INVALID: unique symbol;
export type INVALID = typeof INVALID;
interface CompileFastpassOptions {
    debug?: boolean | undefined;
}
type CompiledFastpass<T> = ((input: unknown) => T | INVALID) & {
    code?: string | undefined;
};
/** Thrown by `compile()` when the schema contains async refinements or transforms. */
export declare class ZodCompileAsyncError extends Error {
    constructor(message?: string);
}
/**
 * Thrown by `compile()` when the schema contains a feature whose semantics the
 * fast path can't fully model. The shim in `zod/compile` catches this and
 * falls back permanently to the runtime parser for that schema. Users calling
 * `z.compile(s)` explicitly will see this thrown and should not catch it —
 * they should not be compiling that schema.
 */
export declare class ZodCompileUnsupportedError extends Error {
    /** Whether a container may absorb this refusal by running the child through the runtime (see `compileChild`). False when running only that node on the runtime is not equivalent to running the whole parse there — a runtime island gets no parse context, so a node that *consumes* issues rather than propagating them would finalize them against the wrong error map and still succeed. */
    readonly islandable: boolean;
    constructor(feature: string, islandable?: boolean);
}
/**
 * AOT-compile a Zod schema. Returns a clone whose `_zod.run` calls a generated
 * fast path first and falls back to the original runtime parser on failure.
 *
 * - Forward direction only. Backward (encode), async, and `skipChecks` paths
 *   bypass the fast path and use the runtime directly.
 * - Throws `ZodCompileAsyncError` at compile time if the schema contains any
 *   async refinement/transform/check. Async detection is static: the
 *   `isAsyncFunction` probe runs on every hoisted user function.
 * - The original schema is unchanged. The clone shares children by reference.
 */
export declare function compile<T extends SomeType>(schema: T): T;
/**
 * Generate the standalone fast-path validator. Returns a function that takes an
 * input and returns either the parsed/transformed value or the `INVALID`
 * sentinel. Internal — consumers should use `compile()`.
 */
export declare function compileFastpass<T extends SomeType>(schema: T, options?: CompileFastpassOptions): CompiledFastpass<core.output<T>>;
export {};
