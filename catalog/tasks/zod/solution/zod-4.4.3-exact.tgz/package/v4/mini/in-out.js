import { visit } from "../core/visit.js";
/** See `classic/in-out.ts`. */
export function input(schema) {
    return visit(schema, {
        pipe: (s) => s._zod.def.in,
    });
}
/** See `classic/in-out.ts`. */
export function output(schema) {
    return visit(schema, {
        pipe: (s) => s._zod.def.out,
    });
}
