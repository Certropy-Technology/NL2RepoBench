"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.input = input;
exports.output = output;
const visit_js_1 = require("../core/visit.cjs");
/** See `classic/in-out.ts`. */
function input(schema) {
    return (0, visit_js_1.visit)(schema, {
        pipe: (s) => s._zod.def.in,
    });
}
/** See `classic/in-out.ts`. */
function output(schema) {
    return (0, visit_js_1.visit)(schema, {
        pipe: (s) => s._zod.def.out,
    });
}
