import { visit } from "../core/visit.js";
/** Returns a copy of the schema with every pipe replaced by its input side. */
export function input(schema) {
    return visit(schema, {
        pipe: (s) => s._zod.def.in,
    });
}
/** Returns a copy of the schema with every pipe replaced by its output side. */
export function output(schema) {
    return visit(schema, {
        pipe: (s) => s._zod.def.out,
    });
}
