"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.input = input;
exports.output = output;
const visit_js_1 = require("../core/visit.cjs");
/** Returns a copy of the schema with every pipe replaced by its input side. */
function input(schema) {
    return (0, visit_js_1.visit)(schema, {
        pipe: (s) => s._zod.def.in,
    });
}
/** Returns a copy of the schema with every pipe replaced by its output side. */
function output(schema) {
    return (0, visit_js_1.visit)(schema, {
        pipe: (s) => s._zod.def.out,
    });
}
