import { Edit, JSONPath, ModificationOptions } from '../main.js';
export declare function removeProperty(text: string, path: JSONPath, options: ModificationOptions): Edit[];
export declare function setProperty(text: string, originalPath: JSONPath, value: any, options: ModificationOptions): Edit[];
export declare function applyEdit(text: string, edit: Edit): string;
export declare function isWS(text: string, offset: number): boolean;
