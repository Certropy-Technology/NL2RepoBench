export declare const cachedSpaces: string[];
export declare const cachedBreakLinesWithSpaces: {
    ' ': {
        '\n': string[];
        '\r': string[];
        '\r\n': string[];
    };
    '\t': {
        '\n': string[];
        '\r': string[];
        '\r\n': string[];
    };
};
export declare const supportedEols: readonly ["\n", "\r", "\r\n"];
export type SupportedEOL = '\n' | '\r' | '\r\n';
