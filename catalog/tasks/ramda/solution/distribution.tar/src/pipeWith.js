var _arity = /*#__PURE__*/require("./internal/_arity.js");
var _curry2 = /*#__PURE__*/require("./internal/_curry2.js");
var head = /*#__PURE__*/require("./head.js");
var _reduce = /*#__PURE__*/require("./internal/_reduce.js");
var tail = /*#__PURE__*/require("./tail.js");
var identity = /*#__PURE__*/require("./identity.js");
/**
 * Performs left-to-right function composition using transforming function. The first function may have
 * any arity; the remaining functions must be unary.
 *
 * **Note:** The result of pipeWith is not automatically curried. Transforming function is not used on the
 * first argument.
 *
 * @func
 * @memberOf R
 * @since v0.26.0
 * @category Function
 * @sig ((* -> *), [((a, b, ..., n) -> o), (o -> p), ..., (x -> y), (y -> z)]) -> ((a, b, ..., n) -> z)
 * @param {Function} transformer The transforming function
 * @param {Array} functions The functions to pipe
 * @return {Function}
 * @see R.andThen, R.composeWith, R.pipe
 * @examples
 *
 *      const pipeWhileNotNil = R.pipeWith((f, res) => R.isNil(res) ? res : f(res));
 *
 *      pipeWhileNotNil([R.prop('age'), R.inc ])({age: 1}) //=> 2
 *      pipeWhileNotNil([R.prop('age'), R.inc ])({}) //=> undefined
 * @symb R.pipeWith(f)([g, h, i])(...args) = f(i, f(h, g(...args)))
 */
var pipeWith = /*#__PURE__*/_curry2(function pipeWith(xf, list) {
  if (list.length <= 0) {
    return identity;
  }
  var headList = head(list);
  var tailList = tail(list);
  return _arity(headList.length, function () {
    return _reduce(function (result, f) {
      return xf.call(this, f, result);
    }, headList.apply(this, arguments), tailList);
  });
});
module.exports = pipeWith;