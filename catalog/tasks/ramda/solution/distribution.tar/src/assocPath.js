var _curry3 = /*#__PURE__*/require("./internal/_curry3.js");
var _isInteger = /*#__PURE__*/require("./internal/_isInteger.js");
var _assoc = /*#__PURE__*/require("./internal/_assoc.js");
var isNil = /*#__PURE__*/require("./isNil.js");
var _prop = /*#__PURE__*/require("./internal/_prop.js");
/**
 * Makes a shallow clone of an object, setting or overriding the nodes required
 * to create the given path, and placing the specific value at the tail end of
 * that path. Note that this copies and flattens prototype properties onto the
 * new object as well. All non-primitive properties are copied by reference.
 *
 * @func
 * @memberOf R
 * @since v0.8.0
 * @category Object
 * @typedefn Idx = String | Int | Symbol
 * @sig [Idx] -> a -> {a} -> {a}
 * @param {Array} path the path to set
 * @param {*} val The new value
 * @param {Object} obj The object to clone
 * @return {Object} A new object equivalent to the original except along the specified path.
 * @see R.dissocPath
 * @example
 *
 *      R.assocPath(['a', 'b', 'c'], 42, {a: {b: {c: 0}}}); //=> {a: {b: {c: 42}}}
 *
 *      // Any missing or non-object keys in path will be overridden
 *      R.assocPath(['a', 'b', 'c'], 42, {a: 5}); //=> {a: {b: {c: 42}}}
 *      R.assocPath(['a', 1, 'c'], 42, {a: []}); // => {a: [undefined, {c: 42}]}
 *      R.assocPath(['a', -1], 42, {a: [1, 2]}); // => {a: [1, 42]}
 */
var assocPath = /*#__PURE__*/_curry3(function assocPath(path, val, obj) {
  if (path.length === 0) {
    return val;
  }
  var idx = path[0];
  if (path.length > 1) {
    var nextObj = _prop(idx, obj);
    if (isNil(nextObj) || typeof nextObj !== 'object') {
      nextObj = _isInteger(path[1]) ? [] : {};
    }
    val = assocPath(Array.prototype.slice.call(path, 1), val, nextObj);
  }
  return _assoc(idx, val, obj);
});
module.exports = assocPath;