var _xfBase = /*#__PURE__*/require("./_xfBase.js");
var XFindLast = /*#__PURE__*/function () {
  function XFindLast(f, xf) {
    this.xf = xf;
    this.f = f;
  }
  XFindLast.prototype['@@transducer/init'] = _xfBase.init;
  XFindLast.prototype['@@transducer/result'] = function (result) {
    return this.xf['@@transducer/result'](this.xf['@@transducer/step'](result, this.last));
  };
  XFindLast.prototype['@@transducer/step'] = function (result, input) {
    if (this.f(input)) {
      this.last = input;
    }
    return result;
  };
  return XFindLast;
}();
function _xfindLast(f) {
  return function (xf) {
    return new XFindLast(f, xf);
  };
}
module.exports = _xfindLast;