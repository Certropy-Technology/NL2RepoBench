export type ParsedTarballUrl = {
    host: string;
    name: string;
    version: string;
};
export declare function parseNpmTarballUrl(url: string): ParsedTarballUrl | null;
