License
-------

.. include:: ../../LICENSE.rst
