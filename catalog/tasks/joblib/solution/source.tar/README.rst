|PyPi| |CIStatus| |ReadTheDocs| |Codecov|

.. |PyPi| image:: https://badge.fury.io/py/joblib.svg
   :target: https://badge.fury.io/py/joblib
   :alt: Joblib version

.. |CIStatus| image:: https://github.com/joblib/joblib/actions/workflows/test.yml/badge.svg
   :target: https://github.com/joblib/joblib/actions/workflows/test.yml?query=branch%3Amain
   :alt: CI status

.. |ReadTheDocs| image:: https://readthedocs.org/projects/joblib/badge/?version=latest
    :target: https://joblib.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status

.. |Codecov| image:: https://codecov.io/gh/joblib/joblib/branch/main/graph/badge.svg
   :target: https://codecov.io/gh/joblib/joblib
   :alt: Codecov coverage


The homepage of joblib with user documentation is located on:

https://joblib.readthedocs.io

Getting the latest code
=======================

To get the latest code using git, simply type::

    git clone https://github.com/joblib/joblib.git

If you don't have git installed, you can download a zip
of the latest code: https://github.com/joblib/joblib/archive/refs/heads/main.zip

Installing
==========

You can use `pip` to install joblib from any directory::

    pip install joblib

or install it in editable mode from the source directory::

    pip install -e .

Dependencies
============

- Joblib supports Python >= 3.10.
- The only dependency is `cloudpickle <https://github.com/cloudpipe/cloudpickle>`_ >= 3.
- Joblib includes its own vendored copy of
  `loky <https://github.com/tomMoral/loky>`_ for process management.
- Joblib can efficiently dump and load numpy arrays but does not require numpy
  to be installed. The oldest numpy version supported is the oldest numpy version
  supported by Python 3.10 (numpy version 1.21.3).
- Joblib can use Dask distributed backend but does not require distributed to be
  installed. The oldest distributed version supported is 2022.8.1.
- Joblib has an optional dependency on
  `python-lz4 <https://pypi.python.org/pypi/lz4>`_ as a faster alternative to
  zlib and gzip for compressed serialization.
- Joblib has an optional dependency on psutil to mitigate memory leaks in
  parallel worker processes.
- Some examples require external dependencies such as pandas. See the
  instructions in the `Building the docs`_ section for details.

Workflow to contribute
======================

To contribute to joblib, first create an account on `github
<https://github.com/>`_. Once this is done, fork the `joblib repository
<https://github.com/joblib/joblib>`_ to have your own repository,
clone it using ``git clone``. Make your changes in a branch of your clone, push
them to your github account, test them locally, and when you are happy with
them, send a pull request to the main repository.

You can use `pre-commit <https://pre-commit.com/#install>`_ to run code style checks
before each commit::

    pip install pre-commit
    pre-commit install

pre-commit checks can be disabled for a single commit with::

    git commit -n

Running the test suite
======================

To run the test suite, you need the pytest (version >= 3) and coverage modules.
Run the test suite using::

    pip install joblib[test]
    pytest joblib

from the root of the project.

Building the docs
=================

To build the docs you need to have sphinx (>=1.4) and some dependencies
installed::

    pip install .[docs]

The docs can then be built with the following command::

    make doc

The html docs are located in the ``doc/_build/html`` directory.


Making a source tarball
=======================

To create a source tarball, eg for packaging or distributing, run the
following command::

    pip install build
    python -m build --sdist

The tarball will be created in the `dist` directory. This command will create
the resulting tarball that can be installed with no extra dependencies than the
Python standard library.

Making a release and uploading it to PyPI
=========================================

To generate a release, create a new Release in GitHub; the release will be
automatically published to PyPI.

Updating the changelog
======================

Changes are listed in the CHANGES.rst file. They must be manually updated
but, the following git command may be used to generate the lines::

    git log --abbrev-commit --date=short --no-merges --sparse
