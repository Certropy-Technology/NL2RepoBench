import fs from 'node:fs'
import http from 'node:http'
import os from 'node:os'
import path from 'node:path'
import { stripVTControlCharacters } from 'node:util'
import { afterEach, assert, describe, expect, test, vi } from 'vitest'
import type { InlineConfig, PluginOption } from '..'
import { isWindows } from '../../shared/utils'
import type { UserConfig, UserConfigExport } from '../config'
import {
  bundleConfigFile,
  defineConfig,
  loadConfigFromFile,
  resolveConfig,
} from '../config'
import { resolveEnvPrefix } from '../env'
import { createLogger } from '../logger'
import type { Logger } from '../logger'
import { resolveServerOptions } from '../server'
import {
  hasBothRollupOptionsAndRolldownOptions,
  mergeConfig,
  normalizePath,
} from '../utils'

describe('mergeConfig', () => {
  test('handles configs with different alias schemas', () => {
    const baseConfig = defineConfig({
      resolve: {
        alias: [
          {
            find: 'foo',
            replacement: 'foo-value',
          },
        ],
      },
    })

    const newConfig = defineConfig({
      resolve: {
        alias: {
          bar: 'bar-value',
          baz: 'baz-value',
        },
      },
    })

    const mergedConfig: UserConfigExport = {
      resolve: {
        alias: [
          {
            find: 'bar',
            replacement: 'bar-value',
          },
          {
            find: 'baz',
            replacement: 'baz-value',
          },
          {
            find: 'foo',
            replacement: 'foo-value',
          },
        ],
      },
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('keep object alias schema', () => {
    const baseConfig = {
      resolve: {
        alias: {
          bar: 'bar-value',
          baz: 'baz-value',
        },
      },
    }

    const newConfig = {
      resolve: {
        alias: {
          bar: 'bar-value-2',
          foo: 'foo-value',
        },
      },
    }

    const mergedConfig = {
      resolve: {
        alias: {
          bar: 'bar-value-2',
          baz: 'baz-value',
          foo: 'foo-value',
        },
      },
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('handles arrays', () => {
    const baseConfig: UserConfigExport = {
      envPrefix: 'string1',
    }

    const newConfig: UserConfigExport = {
      envPrefix: ['string2', 'string3'],
    }

    const mergedConfig: UserConfigExport = {
      envPrefix: ['string1', 'string2', 'string3'],
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('handles assetsInclude', () => {
    const baseConfig: UserConfigExport = {
      assetsInclude: 'some-string',
    }

    const newConfig: UserConfigExport = {
      assetsInclude: ['some-other-string', /regexp?/],
    }

    const mergedConfig: UserConfigExport = {
      assetsInclude: ['some-string', 'some-other-string', /regexp?/],
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('handles input', () => {
    const cases: {
      name: string
      a: UserConfig['input']
      b: UserConfig['input']
      expected: UserConfig['input']
    }[] = [
      {
        name: 'string + string',
        a: 'src/a.ts',
        b: 'src/b.ts',
        expected: ['src/a.ts', 'src/b.ts'],
      },
      {
        name: 'array + string',
        a: ['src/a.ts'],
        b: 'src/b.ts',
        expected: ['src/a.ts', 'src/b.ts'],
      },
      {
        name: 'string + array',
        a: 'src/a.ts',
        b: ['src/b.ts'],
        expected: ['src/a.ts', 'src/b.ts'],
      },
      {
        name: 'array + array',
        a: ['src/a.ts'],
        b: ['src/b.ts'],
        expected: ['src/a.ts', 'src/b.ts'],
      },
      {
        name: 'object + object',
        a: { a: 'src/a.ts', shared: 'src/old.ts' },
        b: { b: 'src/b.ts', shared: 'src/new.ts' },
        expected: { a: 'src/a.ts', b: 'src/b.ts', shared: 'src/new.ts' },
      },
      {
        name: 'string + object',
        a: 'src/a.ts',
        b: { b: 'src/b.ts' },
        expected: { a: 'src/a.ts', b: 'src/b.ts' },
      },
      {
        name: 'object + string',
        a: { a: 'src/a.ts' },
        b: 'src/b.ts',
        expected: { a: 'src/a.ts', b: 'src/b.ts' },
      },
      {
        name: 'array + object',
        a: ['src/a.ts'],
        b: { b: 'src/b.ts' },
        expected: { a: 'src/a.ts', b: 'src/b.ts' },
      },
      {
        name: 'only a',
        a: 'src/a.ts',
        b: undefined,
        expected: 'src/a.ts',
      },
      {
        name: 'only b',
        a: undefined,
        b: 'src/b.ts',
        expected: 'src/b.ts',
      },
    ]

    for (const { name, a, b, expected } of cases) {
      expect(mergeConfig({ input: a }, { input: b }), name).toStrictEqual({
        input: expected,
      })
    }
  })

  test('not handles input not at top level', () => {
    const baseConfig = {
      build: {
        input: 'src/a.ts',
      },
    }

    const newConfig = {
      build: {
        input: 'src/b.ts',
      },
    }

    // nested `input` is overwritten, not merged
    const mergedConfig = {
      build: {
        input: 'src/b.ts',
      },
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('not handles alias not under `resolve`', () => {
    const baseConfig = {
      custom: {
        alias: {
          bar: 'bar-value',
          baz: 'baz-value',
        },
      },
    }

    const newConfig = {
      custom: {
        alias: {
          bar: 'bar-value-2',
          foo: 'foo-value',
        },
      },
    }

    const mergedConfig = {
      custom: {
        alias: {
          bar: 'bar-value-2',
          baz: 'baz-value',
          foo: 'foo-value',
        },
      },
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('merge array correctly', () => {
    const baseConfig = {
      foo: null,
    }

    const newConfig = {
      foo: ['bar'],
    }

    const mergedConfig = {
      foo: ['bar'],
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('handles ssr.noExternal', () => {
    const baseConfig: UserConfig = {
      ssr: {
        noExternal: true,
        external: true,
      },
    }

    const newConfig: UserConfig = {
      ssr: {
        noExternal: ['foo'],
        external: ['bar'],
      },
    }

    const mergedConfig: UserConfig = {
      ssr: {
        noExternal: true,
        external: true,
      },
    }

    // merging either ways, `ssr.noExternal: true` should take highest priority
    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
    expect(mergeConfig(newConfig, baseConfig)).toEqual(mergedConfig)
  })

  test('handles environments.*.resolve.noExternal', () => {
    const baseConfig = {
      environments: {
        ssr: {
          resolve: {
            noExternal: true,
          },
        },
      },
    }

    const newConfig = {
      environments: {
        ssr: {
          resolve: {
            noExternal: ['foo'],
          },
        },
      },
    }

    const mergedConfig = {
      environments: {
        ssr: {
          resolve: {
            noExternal: true,
          },
        },
      },
    }

    // merging either ways, `resolve.noExternal: true` should take highest priority
    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
    expect(mergeConfig(newConfig, baseConfig)).toEqual(mergedConfig)
  })

  test('merge ssr.noExternal and environments.ssr.resolve.noExternal', async () => {
    const oldTrue = await resolveConfig(
      {
        ssr: {
          noExternal: true,
        },
        environments: {
          ssr: {
            resolve: {
              noExternal: ['dep'],
            },
          },
        },
      },
      'serve',
    )
    expect(oldTrue.environments.ssr.resolve.noExternal).toEqual(true)

    const newTrue = await resolveConfig(
      {
        ssr: {
          noExternal: ['dep'],
        },
        environments: {
          ssr: {
            resolve: {
              noExternal: true,
            },
          },
        },
      },
      'serve',
    )
    expect(newTrue.environments.ssr.resolve.noExternal).toEqual(true)
  })

  test('handles server.ws.server', () => {
    const httpServer = http.createServer()

    const baseConfig = { server: { ws: { server: httpServer } } }
    const newConfig = { server: { ws: { server: httpServer } } }

    const mergedConfig = mergeConfig(baseConfig, newConfig)

    // Server instance should not be recreated
    expect(mergedConfig.server.ws.server).toBe(httpServer)
  })

  test('handles server.allowedHosts', () => {
    const baseConfig = {
      server: { allowedHosts: ['example.com'] },
    }

    const newConfig = {
      server: { allowedHosts: true },
    }

    const mergedConfig = {
      server: {
        allowedHosts: true,
        hmr: expect.any(Object),
        ws: expect.any(Object),
      },
    }

    expect(mergeConfig(baseConfig, newConfig)).toEqual(mergedConfig)
  })

  test('throws error with functions', () => {
    const baseConfig = defineConfig(() => ({ base: 'base' }))
    const newConfig = defineConfig(() => ({ base: 'new' }))

    expect(() =>
      mergeConfig(
        // @ts-expect-error TypeScript shouldn't give you to pass a function as argument
        baseConfig,
        newConfig,
      ),
    ).toThrowError('Cannot merge config in form of callback')

    expect(() =>
      mergeConfig(
        {},
        // @ts-expect-error TypeScript shouldn't give you to pass a function as argument
        newConfig,
      ),
    ).toThrowError('Cannot merge config in form of callback')
  })

  test('handles `rolldownOptions`', () => {
    const baseConfig = defineConfig({
      build: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      worker: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      optimizeDeps: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      ssr: {
        optimizeDeps: {
          rolldownOptions: {
            treeshake: false,
          },
        },
      },
    })

    const newConfig = defineConfig({
      build: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      worker: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      optimizeDeps: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      ssr: {
        optimizeDeps: {
          rolldownOptions: {
            output: {
              minifyInternalExports: true,
            },
          },
        },
      },
    })

    const mergedConfig = mergeConfig(baseConfig, newConfig)

    const expected = {
      treeshake: false,
      output: {
        minifyInternalExports: true,
      },
    }
    expect(mergedConfig.build.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.build.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.worker.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.worker.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.ssr.optimizeDeps.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.ssr.optimizeDeps.rolldownOptions).toStrictEqual(
      expected,
    )
  })

  test('handles `build.rolldownOptions`', () => {
    const baseConfig = defineConfig({
      build: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      worker: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      optimizeDeps: {
        rolldownOptions: {
          treeshake: false,
        },
      },
      ssr: {
        optimizeDeps: {
          rolldownOptions: {
            treeshake: false,
          },
        },
      },
    })

    const newConfig = defineConfig({
      build: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      worker: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      optimizeDeps: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      ssr: {
        optimizeDeps: {
          rolldownOptions: {
            output: {
              minifyInternalExports: true,
            },
          },
        },
      },
    })

    const mergedConfig = mergeConfig(baseConfig, newConfig)

    const expected = {
      treeshake: false,
      output: {
        minifyInternalExports: true,
      },
    }
    expect(mergedConfig.build.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.build.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.worker.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.worker.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.ssr.optimizeDeps.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.ssr.optimizeDeps.rolldownOptions).toStrictEqual(
      expected,
    )
  })

  test('syncs `build.rollupOptions` and `build.rolldownOptions`', () => {
    const baseConfig = defineConfig({
      build: {
        rollupOptions: {
          treeshake: false,
        },
      },
      worker: {
        rollupOptions: {
          treeshake: false,
        },
      },
      optimizeDeps: {
        rollupOptions: {
          treeshake: false,
        },
      },
      ssr: {
        optimizeDeps: {
          rollupOptions: {
            treeshake: false,
          },
        },
      },
    })

    const newConfig = defineConfig({
      build: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      worker: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      optimizeDeps: {
        rolldownOptions: {
          output: {
            minifyInternalExports: true,
          },
        },
      },
      ssr: {
        optimizeDeps: {
          rollupOptions: {
            output: {
              minifyInternalExports: true,
            },
          },
        },
      },
    })

    const mergedConfig = mergeConfig(baseConfig, newConfig) as UserConfig

    const expected = {
      treeshake: false,
      output: {
        minifyInternalExports: true,
      },
    }
    expect(mergedConfig.build!.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.build!.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.worker!.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.worker!.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps!.rollupOptions).toStrictEqual(expected)
    expect(mergedConfig.optimizeDeps!.rolldownOptions).toStrictEqual(expected)
    expect(mergedConfig.ssr!.optimizeDeps!.rollupOptions).toStrictEqual(
      expected,
    )
    expect(mergedConfig.ssr!.optimizeDeps!.rolldownOptions).toStrictEqual(
      expected,
    )

    const upOutput = mergedConfig.build!.rollupOptions!.output!
    if (Array.isArray(upOutput)) throw new Error()
    const downOutput = mergedConfig.build!.rolldownOptions!.output!
    if (Array.isArray(downOutput)) throw new Error()
    upOutput.hashCharacters = 'base36'
    expect(upOutput.hashCharacters).toBe('base36')
    expect(downOutput.hashCharacters).toBe('base36')
  })

  test('hasBothRollupOptionsAndRolldownOptions returns false when only rollupOptions is set', () => {
    // When mergeConfig is called with only rollupOptions in the override,
    // setupRollupOptionCompat creates a proxy where rollupOptions === rolldownOptions.
    // hasBothRollupOptionsAndRolldownOptions should return false in this case
    // to avoid false positive warnings.
    const baseConfig = defineConfig({
      build: {}, // Need existing build object for recursive merge to happen
    })
    const newConfig = defineConfig({
      build: {
        rollupOptions: {
          treeshake: false,
        },
      },
    })
    const mergedConfig: UserConfig = mergeConfig(baseConfig, newConfig)

    expect(mergedConfig.build!.rollupOptions).toBeDefined()
    expect(mergedConfig.build!.rolldownOptions).toBeDefined()
    expect(mergedConfig.build!.rollupOptions).toBe(
      mergedConfig.build!.rolldownOptions,
    )

    expect(hasBothRollupOptionsAndRolldownOptions(mergedConfig)).toBe(false)
  })

  test('hasBothRollupOptionsAndRolldownOptions returns true when both are explicitly set to different values', () => {
    const config = defineConfig({
      build: {
        rollupOptions: {
          treeshake: false,
        },
        rolldownOptions: {
          platform: 'neutral',
        },
      },
    })
    expect(hasBothRollupOptionsAndRolldownOptions(config)).toBe(true)
  })

  test('rollupOptions/rolldownOptions.platform', async () => {
    const testRollupOptions = await resolveConfig(
      {
        plugins: [
          {
            name: 'set-rollupOptions-platform',
            configEnvironment(name) {
              if (name === 'ssr') {
                return {
                  build: {
                    rollupOptions: {
                      platform: 'neutral',
                    },
                  },
                }
              }
            },
          },
        ],
      },
      'serve',
    )
    expect(
      testRollupOptions.environments.ssr.build.rolldownOptions.platform,
    ).toBe('neutral')
    expect(
      testRollupOptions.environments.client.build.rolldownOptions.platform,
    ).toBe('browser')

    const testRolldownOptions = await resolveConfig(
      {
        plugins: [
          {
            name: 'set-rollupOptions-platform',
            configEnvironment(name) {
              if (name === 'ssr') {
                return {
                  build: {
                    rolldownOptions: {
                      platform: 'neutral',
                    },
                  },
                }
              }
            },
          },
        ],
      },
      'serve',
    )
    expect(
      testRolldownOptions.environments.ssr.build.rolldownOptions.platform,
    ).toBe('neutral')
    expect(
      testRolldownOptions.environments.client.build.rolldownOptions.platform,
    ).toBe('browser')
  })

  test('resolved build options keep rollupOptions as a live proxy of rolldownOptions', async () => {
    const config = await resolveConfig({}, 'serve')

    for (const build of [
      config.build,
      config.environments.client.build,
      config.environments.ssr.build,
    ]) {
      // Reassigning `rolldownOptions` must be reflected through the `rollupOptions` getter.
      const newOptions = { treeshake: false }
      build.rolldownOptions = newOptions
      expect(build.rollupOptions).toBe(newOptions)

      // Assigning through `rollupOptions` must update `rolldownOptions` too.
      const newerOptions = { treeshake: true }
      build.rollupOptions = newerOptions
      expect(build.rolldownOptions).toBe(newerOptions)
    }
  })

  test('syncs `server.hmr.*` to `server.ws.*`', () => {
    const baseConfig = defineConfig({
      server: {
        hmr: {
          protocol: 'wss',
          host: 'example.com',
          port: 3001,
          clientPort: 443,
          path: '/ws',
          timeout: 60000,
        },
      },
    })

    const mergedConfig = mergeConfig(
      {
        server: { ws: {} },
      },
      baseConfig,
    )

    expect(mergedConfig.server.ws).toStrictEqual({
      protocol: 'wss',
      host: 'example.com',
      port: 3001,
      clientPort: 443,
      path: '/ws',
      timeout: 60000,
    })
    expect(mergedConfig.server.hmr).toStrictEqual({
      protocol: 'wss',
      host: 'example.com',
      port: 3001,
      clientPort: 443,
      path: '/ws',
      timeout: 60000,
      server: undefined,
    })
  })

  test('mergeConfig works with `server.ws` and `server.hmr`', () => {
    const baseConfig = defineConfig({
      server: {
        ws: {
          host: 'old-host.com',
          port: 3001,
        },
      },
    })

    const newConfig = defineConfig({
      server: {
        hmr: {
          host: 'new-host.com',
          port: 3002,
        },
      },
    })

    const mergedConfig = mergeConfig(baseConfig, newConfig)

    expect(mergedConfig.server.ws.host).toBe('new-host.com')
    expect(mergedConfig.server.hmr.host).toBe('new-host.com')
    expect(mergedConfig.server.ws.port).toBe(3002)
    expect(mergedConfig.server.hmr.port).toBe(3002)
  })

  test('`server.hmr.overlay` is not mapped to `server.ws.overlay`', () => {
    const config = mergeConfig(
      {},
      defineConfig({
        server: {
          hmr: {
            overlay: false,
          },
        },
      }),
    )

    expect(config.server.hmr.overlay).toBe(false)
    // overlay should not be synced to ws
    expect(config.server.ws?.overlay).toBeUndefined()
  })

  test('resolveConfig properly syncs hmr and ws', async () => {
    const config = await resolveConfig(
      {
        server: {
          hmr: {
            host: 'test-host.com',
            port: 4000,
          },
        },
      },
      'serve',
    )

    assert(typeof config.server.ws === 'object')
    expect(config.server.ws.host).toBe('test-host.com')
    expect(config.server.ws.port).toBe(4000)

    assert(typeof config.server.hmr === 'object')
    config.server.hmr!.host = 'new-host.com'

    expect(config.server.ws.host).toBe('new-host.com')
    expect(config.server.hmr.host).toBe('new-host.com')
  })

  describe('later plugin can read `rollupOptions` set via `rolldownOptions` in earlier plugin', () => {
    test('top-level config', async () => {
      expect.assertions(2)
      await resolveConfig(
        {
          plugins: [
            {
              name: 'plugin-a',
              config() {
                return {
                  build: {
                    rolldownOptions: {
                      platform: 'neutral',
                    },
                  },
                  worker: {
                    rolldownOptions: {
                      platform: 'neutral',
                    },
                  },
                }
              },
            },
            {
              name: 'plugin-b',
              config(config) {
                expect(config.build?.rollupOptions?.platform).toBe('neutral')
                expect(config.worker?.rollupOptions?.platform).toBe('neutral')
              },
            },
          ],
        },
        'build',
      )
    })

    test('new `environments` object', async () => {
      expect.assertions(1)
      await resolveConfig(
        {
          plugins: [
            {
              name: 'plugin-a',
              config() {
                return {
                  environments: {
                    ssr: {
                      build: {
                        rolldownOptions: {
                          platform: 'neutral',
                        },
                      },
                    },
                  },
                }
              },
            },
            {
              name: 'plugin-b',
              config(config) {
                expect(
                  config.environments?.ssr?.build?.rollupOptions?.platform,
                ).toBe('neutral')
              },
            },
          ],
        },
        'build',
      )
    })

    test('new environment on existing `environments` object', async () => {
      expect.assertions(1)
      await resolveConfig(
        {
          environments: {
            // environments exists, but no ssr
            client: {},
          },
          plugins: [
            {
              name: 'plugin-a',
              config() {
                return {
                  environments: {
                    ssr: {
                      build: {
                        rolldownOptions: {
                          platform: 'neutral',
                        },
                      },
                    },
                  },
                }
              },
            },
            {
              name: 'plugin-b',
              config(config) {
                expect(
                  config.environments?.ssr?.build?.rollupOptions?.platform,
                ).toBe('neutral')
              },
            },
          ],
        },
        'build',
      )
    })
  })
})

describe('resolveEnvPrefix', () => {
  test(`use 'VITE_' as default value`, () => {
    const config: UserConfig = {}
    expect(resolveEnvPrefix(config)).toMatchObject(['VITE_'])
  })

  test(`throw error if envPrefix contains ''`, () => {
    let config: UserConfig = { envPrefix: '' }
    expect(() => resolveEnvPrefix(config)).toThrow()
    config = { envPrefix: ['', 'CUSTOM_'] }
    expect(() => resolveEnvPrefix(config)).toThrow()
  })

  test(`show a warning message if envPrefix contains a whitespace`, () => {
    const consoleWarnSpy = vi
      .spyOn(console, 'warn')
      .mockImplementation(() => {})
    let config: UserConfig = { envPrefix: 'WITH SPACE' }
    resolveEnvPrefix(config)
    expect(consoleWarnSpy).toHaveBeenCalled()
    config = { envPrefix: ['CUSTOM_', 'ANOTHER SPACE'] }
    resolveEnvPrefix(config)
    expect(consoleWarnSpy).toHaveBeenCalledTimes(2)
    consoleWarnSpy.mockRestore()
  })

  test('should work correctly for valid envPrefix value', () => {
    const config: UserConfig = { envPrefix: ['CUSTOM_'] }
    expect(resolveEnvPrefix(config)).toMatchObject(['CUSTOM_'])
  })
})

describe('preview config', () => {
  const serverConfig = () => ({
    port: 3003,
    strictPort: true,
    host: true,
    open: true,
    headers: {
      'Cache-Control': 'no-store',
    },
    proxy: { '/foo': 'http://localhost:4567' },
    cors: true,
  })

  test('preview inherits server config with default port', async () => {
    const config: InlineConfig = {
      server: serverConfig(),
    }
    expect(await resolveConfig(config, 'serve')).toMatchObject({
      preview: {
        ...serverConfig(),
        port: 4173,
      },
    })
  })

  test('preview inherits server config with port override', async () => {
    const config: InlineConfig = {
      server: serverConfig(),
      preview: {
        port: 3006,
      },
    }
    expect(await resolveConfig(config, 'serve')).toMatchObject({
      preview: {
        ...serverConfig(),
        port: 3006,
      },
    })
  })

  const previewConfig = () => ({
    port: 3006,
    strictPort: false,
    open: false,
    host: false,
    proxy: { '/bar': 'http://localhost:3010' },
    cors: false,
  })

  test('preview overrides server config', async () => {
    const config: InlineConfig = {
      server: serverConfig(),
      preview: previewConfig(),
    }
    expect(await resolveConfig(config, 'serve')).toMatchObject({
      preview: previewConfig(),
    })
  })
})

describe('resolveConfig', () => {
  const keepScreenMergePlugin = (): PluginOption => {
    return {
      name: 'vite-plugin-keep-screen-merge',
      config() {
        return { clearScreen: false }
      },
    }
  }

  const keepScreenOverridePlugin = (): PluginOption => {
    return {
      name: 'vite-plugin-keep-screen-override',
      config(config) {
        config.clearScreen = false
      },
    }
  }

  test('plugin merges `clearScreen` option', async () => {
    const config1: InlineConfig = { plugins: [keepScreenMergePlugin()] }
    const config2: InlineConfig = {
      plugins: [keepScreenMergePlugin()],
      clearScreen: true,
    }

    const results1 = await resolveConfig(config1, 'build')
    const results2 = await resolveConfig(config2, 'build')

    expect(results1.clearScreen).toBe(false)
    expect(results2.clearScreen).toBe(false)
  })

  test('plugin overrides `clearScreen` option', async () => {
    const config1: InlineConfig = { plugins: [keepScreenOverridePlugin()] }
    const config2: InlineConfig = {
      plugins: [keepScreenOverridePlugin()],
      clearScreen: true,
    }

    const results1 = await resolveConfig(config1, 'build')
    const results2 = await resolveConfig(config2, 'build')

    expect(results1.clearScreen).toBe(false)
    expect(results2.clearScreen).toBe(false)
  })

  test('resolveConfig with root path including "#" and "?" and "*" should warn ', async () => {
    expect.assertions(1)

    const logger = createLogger('info')
    logger.warn = (str) => {
      expect(str).to.include(
        'Consider renaming the directory without the characters',
      )
    }

    await resolveConfig({ root: './inc?ud#s*', customLogger: logger }, 'build')
  })

  test('syncs `build.rollupOptions` and `build.rolldownOptions`', async () => {
    const resolved = await resolveConfig({}, 'build')
    expect(resolved.build!.rollupOptions).toStrictEqual(
      resolved.build!.rolldownOptions,
    )
    expect(resolved.worker!.rollupOptions).toStrictEqual(
      resolved.worker!.rolldownOptions,
    )
    expect(resolved.optimizeDeps!.rollupOptions).toStrictEqual(
      resolved.optimizeDeps!.rolldownOptions,
    )
  })

  test('top-level input applies to the client environment only (non-inherit)', async () => {
    const config = await resolveConfig({ input: 'src/main.ts' }, 'serve')

    expect(config.input).toBe('src/main.ts')
    expect(config.environments.client.input).toBe('src/main.ts')
    expect(
      config.environments.client.build.rolldownOptions.input,
    ).toBeUndefined()
    expect(config.environments.ssr.input).toBeUndefined()
    expect(config.environments.ssr.build.rolldownOptions.input).toBeUndefined()
  })

  test('per-environment input overrides the top-level value', async () => {
    const config = await resolveConfig(
      {
        input: 'src/main.ts',
        environments: {
          ssr: { input: 'src/entry-server.ts' },
        },
      },
      'serve',
    )

    expect(config.environments.client.input).toBe('src/main.ts')
    expect(config.environments.ssr.input).toBe('src/entry-server.ts')
  })

  test('keeps array input relative to the root', async () => {
    const config = await resolveConfig(
      { input: ['src/a.ts', 'src/b.ts'] },
      'serve',
    )

    expect(config.environments.client.input).toEqual(['src/a.ts', 'src/b.ts'])
  })

  test('keeps record input relative to the root', async () => {
    const config = await resolveConfig(
      { input: { main: 'src/a.ts', admin: 'src/b.ts' } },
      'serve',
    )

    expect(config.environments.client.input).toEqual({
      main: 'src/a.ts',
      admin: 'src/b.ts',
    })
  })

  test('reserves glob characters in input', async () => {
    const cases: { name: string; input: UserConfig['input'] }[] = [
      { name: 'wildcard', input: 'src/*.ts' },
      { name: 'single char', input: 'src/page?.ts' },
      { name: 'character class', input: 'src/[id].ts' },
      { name: 'brace expansion', input: 'src/{a,b}.ts' },
      { name: 'extglob group', input: 'src/?(group).ts' },
      { name: 'negation', input: 'src/!(main).ts' },
      { name: 'extglob prefix +', input: 'src/+(page).ts' },
      { name: 'extglob prefix @', input: 'src/@(page).ts' },
      { name: 'array element', input: ['src/main.ts', 'src/*.ts'] },
      { name: 'record', input: { main: 'src/*.ts' } },
    ]

    for (const { name, input } of cases) {
      await expect(resolveConfig({ input }, 'serve'), name).rejects.toThrow(
        /`input` cannot contain glob characters/,
      )
    }
  })

  test('support escaped input', async () => {
    const cases: {
      name: string
      input: UserConfig['input']
      expected: UserConfig['input']
    }[] = [
      {
        name: 'glob',
        input: 'src/\\*.ts',
        expected: 'src/*.ts',
      },
      {
        name: 'array element',
        input: ['src/\\*.ts'],
        expected: ['src/*.ts'],
      },
      {
        name: 'record',
        input: { main: 'src/\\*.ts' },
        expected: { main: 'src/*.ts' },
      },
    ]

    for (const { name, input, expected } of cases) {
      await expect(
        resolveConfig({ input }, 'serve'),
        name,
      ).resolves.toMatchObject({
        input: expected,
      })
    }
  })

  test('allows non-glob special characters in input', async () => {
    const cases: {
      name: string
      input: UserConfig['input']
      expected: UserConfig['input']
    }[] = [
      {
        name: 'special characters',
        input: 'src/a-b_c$.ts',
        expected: 'src/a-b_c$.ts',
      },
      ...(isWindows
        ? [
            {
              name: 'windows path',
              input: 'src\\foo.ts',
              expected: 'src\\foo.ts',
            },
          ]
        : []),
    ]

    for (const { name, input, expected } of cases) {
      await expect(
        resolveConfig({ input }, 'serve'),
        name,
      ).resolves.toMatchObject({
        input: expected,
      })
    }
  })

  test('is used as the default for build.lib.entry when entry is omitted', async () => {
    const config = await resolveConfig(
      {
        input: 'src/lib.ts',
        build: { lib: { name: 'MyLib' } },
      },
      'build',
    )

    expect(config.build.lib && config.build.lib.entry).toBe('src/lib.ts')
  })

  test('explicit build.lib.entry overrides the top-level input', async () => {
    const config = await resolveConfig(
      {
        input: 'src/lib.ts',
        build: { lib: { entry: 'src/explicit.ts', name: 'MyLib' } },
      },
      'build',
    )

    expect(config.build.lib && config.build.lib.entry).toBe('src/explicit.ts')
  })
})

test('config compat 1', async () => {
  const config = await resolveConfig(
    {
      resolve: {
        conditions: ['client1'],
      },
      ssr: {
        resolve: {
          conditions: ['ssr1'],
        },
      },
      plugins: [
        {
          name: 'test',
          config() {
            return {
              environments: {
                client: {
                  resolve: {
                    conditions: ['client2'],
                  },
                },
                ssr: {
                  resolve: {
                    conditions: ['ssr2'],
                  },
                },
              },
            }
          },
        },
      ],
    },
    'serve',
  )
  expect(config.resolve.conditions).toMatchInlineSnapshot(`
    [
      "client1",
      "client2",
    ]
  `)
  expect(config.environments.client.resolve.conditions).toMatchInlineSnapshot(`
    [
      "client1",
      "client2",
    ]
  `)
  expect(config.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "ssr1",
      "ssr2",
    ]
  `)
  expect(config.environments.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "ssr1",
      "ssr2",
    ]
  `)
})

test('config compat 2', async () => {
  const config = await resolveConfig(
    {
      environments: {
        client: {
          resolve: {
            conditions: ['client1'],
          },
        },
        ssr: {
          resolve: {
            conditions: ['ssr1'],
          },
        },
      },
      plugins: [
        {
          name: 'test',
          config() {
            return {
              resolve: {
                conditions: ['client2'],
              },
              ssr: {
                resolve: {
                  conditions: ['ssr2'],
                },
              },
            }
          },
        },
      ],
    },
    'serve',
  )
  expect(config.resolve.conditions).toMatchInlineSnapshot(`
    [
      "client2",
      "client1",
    ]
  `)
  expect(config.environments.client.resolve.conditions).toMatchInlineSnapshot(`
    [
      "client2",
      "client1",
    ]
  `)
  expect(config.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "ssr2",
      "ssr1",
    ]
  `)
  expect(config.environments.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "ssr2",
      "ssr1",
    ]
  `)
})

test('config compat 3', async () => {
  const config = await resolveConfig({}, 'serve')
  expect(config.resolve.conditions).toMatchInlineSnapshot(`
    [
      "module",
      "browser",
      "development|production",
    ]
  `)
  expect(config.environments.client.resolve.conditions).toMatchInlineSnapshot(`
    [
      "module",
      "browser",
      "development|production",
    ]
  `)
  expect(config.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "module",
      "node",
      "development|production",
    ]
  `)
  expect(config.environments.ssr.resolve?.conditions).toMatchInlineSnapshot(`
    [
      "module",
      "node",
      "development|production",
    ]
  `)
})

test('configEnvironment mutation does not leak between environments', async () => {
  const resolved = await resolveConfig(
    {
      environments: {
        custom1: {},
        custom2: {},
      },
      plugins: [
        {
          name: 'test-mutate-env',
          configEnvironment(name, config) {
            if (name === 'custom1') {
              config.resolve ??= {}
              config.resolve.noExternal = true
            }
          },
        },
      ],
    },
    'serve',
  )

  expect(resolved.environments.custom1.resolve.noExternal).toBe(true)
  expect(resolved.environments.custom2.resolve.noExternal).not.toBe(true)
})

test('build and environments.client.build has the same reference', async () => {
  const nameCache = {}
  const resolved = await resolveConfig(
    {
      build: {
        terserOptions: {
          nameCache,
        },
      },
    },
    'serve',
  )

  expect(resolved.build.terserOptions.nameCache).toBe(nameCache)
  expect(resolved.environments.client.build.terserOptions.nameCache).toBe(
    resolved.build.terserOptions.nameCache,
  )
})

test('preTransformRequests', async () => {
  async function testConfig(inlineConfig: InlineConfig) {
    return Object.fromEntries(
      Object.entries(
        (await resolveConfig(inlineConfig, 'serve')).environments,
      ).map(([name, e]) => [name, e.dev.preTransformRequests]),
    )
  }

  expect(
    await testConfig({
      environments: {
        custom: {},
        customTrue: {
          dev: {
            preTransformRequests: true,
          },
        },
        customFalse: {
          dev: {
            preTransformRequests: false,
          },
        },
      },
    }),
  ).toMatchInlineSnapshot(`
    {
      "client": true,
      "custom": false,
      "customFalse": false,
      "customTrue": true,
      "ssr": false,
    }
  `)

  expect(
    await testConfig({
      server: {
        preTransformRequests: true,
      },
      environments: {
        custom: {},
        customTrue: {
          dev: {
            preTransformRequests: true,
          },
        },
        customFalse: {
          dev: {
            preTransformRequests: false,
          },
        },
      },
    }),
  ).toMatchInlineSnapshot(`
    {
      "client": true,
      "custom": true,
      "customFalse": false,
      "customTrue": true,
      "ssr": true,
    }
  `)

  expect(
    await testConfig({
      server: {
        preTransformRequests: false,
      },
      environments: {
        custom: {},
        customTrue: {
          dev: {
            preTransformRequests: true,
          },
        },
        customFalse: {
          dev: {
            preTransformRequests: false,
          },
        },
      },
    }),
  ).toMatchInlineSnapshot(`
    {
      "client": false,
      "custom": false,
      "customFalse": false,
      "customTrue": true,
      "ssr": false,
    }
  `)
})

describe('loadConfigFromFile', () => {
  const fixtures = path.resolve(import.meta.dirname, './fixtures/config')

  describe('native-incompatibility warnings', () => {
    const compatRoot = path.resolve(fixtures, './native-compat')

    // eslint-disable-next-line n/no-unsupported-features/node-builtins
    const supportsTypeStripping = !!process.features.typescript

    const loadWithWarnings = async (
      dir: string,
      configFile = 'vite.config.js',
    ) => {
      const logger = createLogger('info')
      const warn = vi.spyOn(logger, 'warn').mockImplementation(() => {})
      const root = path.resolve(compatRoot, dir)
      await loadConfigFromFile(
        {} as any,
        path.resolve(root, configFile),
        root,
        undefined,
        logger,
        'bundle',
      )
      const messages = warn.mock.calls.map((c) =>
        stripVTControlCharacters(c[0]),
      )
      warn.mockRestore()
      return messages
    }

    test('warns on __dirname / __filename', async () => {
      const messages = await loadWithWarnings('dirname')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - \`__dirname\` (vite.config.js:3:29). Use \`import.meta.dirname\` instead
          - \`__filename\` (vite.config.js:4:30). Use \`import.meta.filename\` instead
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    // uses a `.ts` config with TypeScript-only syntax; skipped on Node
    // versions without type stripping support
    test.skipIf(!supportsTypeStripping)(
      'warns on __dirname in a config using TypeScript syntax',
      async () => {
        const messages = await loadWithWarnings('ts-syntax', 'vite.config.ts')
        expect(messages).toMatchInlineSnapshot(`
          [
            "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
            - \`__dirname\` (vite.config.ts:10:29). Use \`import.meta.dirname\` instead
          Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
          ]
        `)
      },
    )

    test('warns on extension-less import', async () => {
      const messages = await loadWithWarnings('extensionless')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - import "./helper" without a file extension (vite.config.js:1:23). Add the file extension
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    test('warns on directory-index import', async () => {
      const messages = await loadWithWarnings('directory-index')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - import "./plugins" resolves to a directory index (vite.config.js:1:25). Import the index file directly
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    test('warns on JSON import without attributes', async () => {
      const messages = await loadWithWarnings('json')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - JSON import "./data.json" without import attributes (vite.config.js:1:18). Add \`with { type: 'json' }\`
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    test('does not warn on JSON import with attributes', async () => {
      expect(await loadWithWarnings('json-ok')).toHaveLength(0)
    })

    test('warns on an extension-less import that resolves to JSON', async () => {
      const messages = await loadWithWarnings('json-extensionless')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - import "./foo" resolves to a JSON file (vite.config.js:1:18). Import it with a \`.json\` extension and \`with { type: 'json' }\`
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    test('does not warn on a native-compatible config', async () => {
      expect(await loadWithWarnings('clean')).toHaveLength(0)
    })

    test('does not warn for a CJS config using __dirname', async () => {
      expect(await loadWithWarnings('cjs', 'vite.config.cjs')).toHaveLength(0)
    })

    test('warns for an ESM file imported by a CJS config', async () => {
      const messages = await loadWithWarnings(
        'cjs-imports-esm',
        'vite.config.cjs',
      )
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - \`__dirname\` (esm-helper.mjs:1:35). Use \`import.meta.dirname\` instead
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })

    test('warns on ESM syntax in a config under a `type: commonjs` package', async () => {
      const messages = await loadWithWarnings('esm-in-commonjs-pkg')
      expect(messages).toMatchInlineSnapshot(`
        [
          "(!) Your Vite config uses features that are unsupported by \`configLoader: 'native'\`, which is planned to become the default in a future major version of Vite:
          - ESM syntax in a file loaded as CommonJS (vite.config.js:1:1). Use a \`.mjs\` extension or set \`"type": "module"\` in the closest package.json
        Set \`VITE_CONFIG_NATIVE_IGNORE_WARNING=true\` to suppress this warning.",
        ]
      `)
    })
  })

  describe('load default files', () => {
    const root = path.resolve(fixtures, './loadConfigFromFile')

    let writtenConfig: string | undefined
    afterEach(() => {
      if (writtenConfig) {
        fs.unlinkSync(path.resolve(root, writtenConfig))
      }
      fs.unlinkSync(path.resolve(root, 'package.json'))
    })

    const writeConfig = (fileName: string, content: string) => {
      fs.writeFileSync(path.resolve(root, fileName), content)
      writtenConfig = fileName
    }
    const writePackageJson = (typeField: string | undefined) => {
      fs.writeFileSync(
        path.resolve(root, 'package.json'),
        JSON.stringify({
          name: '@vitejs/test-load-config-from-file',
          type: typeField,
        }),
      )
    }

    const canLoadConfig = async () => {
      const result = await loadConfigFromFile(
        { command: 'build', mode: 'production' },
        undefined,
        root,
        'silent',
      )
      expect(result).toBeTruthy()
      expect(result?.config).toStrictEqual({ define: { foo: 1 } })
      expect(path.normalize(result!.path)).toBe(
        path.resolve(root, writtenConfig!),
      )
    }

    const cases = [
      {
        fileName: 'vite.config.js',
        content: 'export default { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.js',
        content: 'export default { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.cjs',
        content: 'module.exports = { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.cjs',
        content: 'module.exports = { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.mjs',
        content: 'export default { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.mjs',
        content: 'export default { define: { foo: 1 } }',
      },
      {
        fileName: 'vite.config.ts',
        content: 'export default { define: { foo: 1 as number } }',
      },
      {
        fileName: 'vite.config.ts',
        content: 'export default { define: { foo: 1 as number } }',
      },
      {
        fileName: 'vite.config.mts',
        content: 'export default { define: { foo: 1 as number } }',
      },
      {
        fileName: 'vite.config.mts',
        content: 'export default { define: { foo: 1 as number } }',
      },
      {
        fileName: 'vite.config.cts',
        content: 'module.exports = { define: { foo: 1 as number } }',
      },
      {
        fileName: 'vite.config.cts',
        content: 'module.exports = { define: { foo: 1 as number } }',
      },
    ]

    for (const { fileName, content } of cases) {
      for (const typeField of [undefined, 'module']) {
        test(`load ${fileName}${typeField ? ' with package#type module' : ''}`, async () => {
          writePackageJson(typeField)
          writeConfig(fileName, content)
          await canLoadConfig()
        })
      }
    }
  })

  test('can import values', async () => {
    const { config } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './entry/vite.config.ts'),
      path.resolve(fixtures, './entry'),
    ))!
    expect(config).toMatchInlineSnapshot(`
      {
        "array": [
          [
            1,
            3,
          ],
          [
            2,
            4,
          ],
        ],
        "importsField": "imports-field",
        "moduleCondition": "import condition",
      }
    `)
  })

  test('loadConfigFromFile with import attributes', async () => {
    const { config } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './entry/vite.config.import-attributes.ts'),
      path.resolve(fixtures, './entry'),
    ))!
    expect(config).toMatchInlineSnapshot(`
        {
          "jsonValue": "vite",
        }
      `)
  })

  test('cjs module vars are supported in esm', async () => {
    const { config } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './cjs-module-vars-in-esm/vite.config.ts'),
      path.resolve(fixtures, './cjs-module-vars-in-esm'),
      'silent',
    ))!
    const c = config as any
    expect(c.dirname).toContain('cjs-module-vars-in-esm')
    expect(c.filename).toContain('vite.config.ts')
  })

  test('import.meta properties are supported', async () => {
    const { config } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './import-meta/vite.config.ts'),
      path.resolve(fixtures, './import-meta'),
    ))!

    const c = config as any
    expect(c.isMain).toBe(false)
    expect(c.url).toContain('file://')
    expect(c.dirname).toContain('import-meta')
    expect(c.filename).toContain('vite.config.ts')
    expect(c.resolved).toBe(c.url)
    expect(c.resolvedMultiline).toBe(c.url)
  })

  test('shebang is preserved at the top of the file', async () => {
    const { config } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './shebang/vite.config.ts'),
      path.resolve(fixtures, './shebang'),
    ))!

    const c = config as any
    expect(c.dirname).toContain('shebang')
  })

  test('injected variables follow a hashbang ending in CRLF', async () => {
    const { config, path: configPath } = (await loadConfigFromFile(
      {} as any,
      path.resolve(fixtures, './shebang-crlf/vite.config.ts'),
      path.resolve(fixtures, './shebang-crlf'),
    ))!

    const configFile = fs.readFileSync(configPath, 'utf8')
    expect(configFile).toContain('\r\n')

    const c = config as any
    expect(c.dirname).toContain('shebang-crlf')
  })

  test('sourcemap of a nested config file points to itself', async () => {
    const configPath = path.resolve(
      fixtures,
      './nested/.nested/vite.config.mts',
    )
    const { code } = await bundleConfigFile(configPath, true)
    const [, base64Map] = code.match(
      /\/\/# sourceMappingURL=data:application\/json;charset=utf-8;base64,(.+)/,
    )!
    const map = JSON.parse(Buffer.from(base64Map, 'base64').toString())
    expect(map.sources.map(normalizePath)).toStrictEqual([
      normalizePath(configPath),
    ])
  })

  describe('loadConfigFromFile with configLoader: native', () => {
    const fixtureRoot = path.resolve(fixtures, './native-import')

    test('imports a basic js config', async () => {
      const result = (await loadConfigFromFile(
        {} as any,
        path.resolve(fixtureRoot, 'basic.js'),
        fixtureRoot,
        undefined,
        undefined,
        'native',
      ))!
      expect(result.config).toMatchInlineSnapshot(`
        {
          "value": "works",
        }
      `)
      expect(result.dependencies.length).toBe(0)
    })
  })

  describe('cacheDir resolution', () => {
    // Use /tmp to avoid findNearestPackageData finding a parent package.json
    const tmpBase = path.join(os.tmpdir(), 'vite-cachedir-test')

    afterEach(() => {
      if (fs.existsSync(tmpBase)) {
        fs.rmSync(tmpBase, { recursive: true, force: true })
      }
    })

    test('uses node_modules/.vite when node_modules exists without package.json', async () => {
      const tempDir = path.join(tmpBase, 'with-node-modules')
      const nodeModulesDir = path.join(tempDir, 'node_modules')
      fs.mkdirSync(nodeModulesDir, { recursive: true })

      const config = await resolveConfig({ root: tempDir }, 'serve')

      expect(config.cacheDir).toBe(
        normalizePath(
          path.resolve(fs.realpathSync.native(tempDir), 'node_modules/.vite'),
        ),
      )
    })

    test('uses .vite when neither package.json nor node_modules exist', async () => {
      const tempDir = path.join(tmpBase, 'empty')
      fs.mkdirSync(tempDir, { recursive: true })

      const config = await resolveConfig({ root: tempDir }, 'serve')

      expect(config.cacheDir).toBe(
        normalizePath(path.resolve(fs.realpathSync.native(tempDir), '.vite')),
      )
    })
  })
})

describe('root resolution', () => {
  const fixtureRoot = path.resolve(
    import.meta.dirname,
    './fixtures/config/root-resolution',
  )
  const realDir = path.join(fixtureRoot, 'real')
  const linkDir = path.join(fixtureRoot, 'link')

  test('resolves a symlinked root to its real path', async () => {
    const config = await resolveConfig({ root: linkDir }, 'serve')
    expect(config.root).toBe(normalizePath(fs.realpathSync.native(realDir)))
  })

  test('keeps a symlinked root when resolve.preserveSymlinks is true', async () => {
    const config = await resolveConfig(
      { root: linkDir, resolve: { preserveSymlinks: true } },
      'serve',
    )
    expect(config.root).toBe(normalizePath(linkDir))
  })
})

describe('resolveServerOptions', () => {
  const warnFn = vi.fn()
  const logger = { warn: warnFn } as unknown as Logger

  afterEach(() => {
    delete process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS
  })

  test('adds single host from __VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS = 'example.com'
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: [] },
      logger,
    )
    expect(resolved.allowedHosts).toEqual(['example.com'])
  })

  test('adds multiple hosts from __VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS =
      'example.com,test.com,dev.example.org'
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: [] },
      logger,
    )
    expect(resolved.allowedHosts).toEqual([
      'example.com',
      'test.com',
      'dev.example.org',
    ])
  })

  test('trims whitespace from hosts in __VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS =
      ' example.com , test.com , dev.example.org '
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: [] },
      logger,
    )
    expect(resolved.allowedHosts).toEqual([
      'example.com',
      'test.com',
      'dev.example.org',
    ])
  })

  test('filters empty hosts from __VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS =
      'example.com,,test.com,,'
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: [] },
      logger,
    )
    expect(resolved.allowedHosts).toEqual(['example.com', 'test.com'])
  })

  test('appends to existing allowedHosts', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS = 'new.com,another.com'
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: ['existing.com'] },
      logger,
    )
    expect(resolved.allowedHosts).toEqual([
      'existing.com',
      'new.com',
      'another.com',
    ])
  })

  test('does not modify allowedHosts when set to true', async () => {
    process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS = 'example.com'
    const resolved = await resolveServerOptions(
      '/root',
      { allowedHosts: true },
      logger,
    )
    expect(resolved.allowedHosts).toBe(true)
  })

  test('throw an error if it contains `"` or `\'` or `\\`', async () => {
    const envs = ['"example.com"', "'example.com'", '\\example.com']
    for (const env of envs) {
      process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS = env
      const resolved = await resolveServerOptions(
        '/root',
        { allowedHosts: [] },
        logger,
      )
      expect(resolved.allowedHosts).toEqual([])
      expect(warnFn).toHaveBeenCalledWith(
        expect.stringContaining(
          'Skipping additional allowed hosts from environment variable due to reserved characters',
        ),
      )
      warnFn.mockClear()
    }
  })
})
