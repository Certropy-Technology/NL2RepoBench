module.exports = 'require condition'
