import { setTimeout } from 'node:timers/promises'
import getEtag from 'etag'
import colors from 'picocolors'
import type { RolldownOutput } from 'rolldown'
import {
  type BindingClientHmrUpdate,
  type DevEngine,
  dev,
} from 'rolldown/experimental'
import { ChunkMetadataMap, resolveRolldownOptions } from '../build'
import { BUNDLED_DEV_CLIENT_FILENAME } from '../constants'
import { getHmrImplementation } from '../plugins/clientInjections'
import { createDebugger, formatAndTruncateFileList } from '../utils'
import { convertToDevWatchOptions } from '../watch'
import type { DevEnvironment } from './environment'
import { type NormalizedHotChannelClient, debugHmr, getShortName } from './hmr'
import { prepareError } from './middlewares/error'

const debug = createDebugger('vite:full-bundle-mode')

type HmrOutput = BindingClientHmrUpdate['update']

type MemoryFile = {
  source: string | Uint8Array
  etag?: string
}

export class MemoryFiles {
  private files = new Map<string, MemoryFile | (() => MemoryFile)>()

  get size(): number {
    return this.files.size
  }

  get(file: string): MemoryFile | undefined {
    const result = this.files.get(file)
    if (result === undefined) {
      return undefined
    }
    if (typeof result === 'function') {
      const content = result()
      this.files.set(file, content)
      return content
    }
    return result
  }

  set(file: string, content: MemoryFile | (() => MemoryFile)): void {
    this.files.set(file, content)
  }

  has(file: string): boolean {
    return this.files.has(file)
  }

  clear(): void {
    this.files.clear()
  }
}

export class BundledDev {
  private _devEngine!: DevEngine
  private viteRuntime?: string
  private initialBuildCompleted = false
  private _closed = false
  private clients = new Clients()
  private debouncedFullReload = debounce(20, () => {
    this.environment.hot.send({ type: 'full-reload', path: '*' })
    this.environment.logger.info(colors.green(`page reload`), {
      timestamp: true,
    })
  })

  private fullReloadPending = false

  private reloadNeededClientIds = new Set<string>()
  private debouncedReloadNeededFlush = debounce(20, () => {
    if (this.lastBuildError || this.reloadNeededClientIds.size === 0) return
    for (const clientId of this.reloadNeededClientIds) {
      this.clients.get(clientId)?.send({ type: 'full-reload', path: '*' })
    }
    this.reloadNeededClientIds.clear()
    this.environment.logger.info(colors.green(`page reload`), {
      timestamp: true,
    })
  })

  private lastBuildError: Error | null = null

  memoryFiles: MemoryFiles = new MemoryFiles()

  constructor(private environment: DevEnvironment) {
    if (environment.name !== 'client') {
      throw new Error(
        'currently full bundle mode is only available for client environment',
      )
    }
  }

  private get devEngine(): DevEngine {
    if (!this._devEngine) {
      throw new Error(`dev engine was not yet initialized`)
    }
    return this._devEngine
  }

  private pendingPayloadFilenames = new Set<string>()

  get hasBuildOutput(): boolean {
    return (
      this.memoryFiles.size > 1 ||
      (this.memoryFiles.size === 1 &&
        !this.memoryFiles.has(BUNDLED_DEV_CLIENT_FILENAME))
    )
  }

  async listen(): Promise<void> {
    this._closed = false
    debug?.('INITIAL: setup bundle options')
    const rolldownOptions = await this.getRolldownOptions()
    // NOTE: only single outputOptions is supported here
    if (
      Array.isArray(rolldownOptions.output) &&
      rolldownOptions.output.length > 1
    ) {
      throw new Error('multiple output options are not supported in dev mode')
    }
    const outputOptions = (
      Array.isArray(rolldownOptions.output)
        ? rolldownOptions.output[0]
        : rolldownOptions.output
    )!

    this.environment.hot.on(
      'vite:client-connected',
      async (payload, client) => {
        this.clients.setupIfNeeded(client, payload.clientId)
        this.devEngine.registerClient(payload.clientId)
      },
    )
    this.environment.hot.on('vite:client:connect', (_payload, client) => {
      // Replay the cached build error to freshly connected clients.
      if (this.lastBuildError) {
        debug?.('REPLAY: replaying last build error to newly connected client')

        client.send({
          type: 'error',
          err: prepareError(this.lastBuildError),
        })
      }
    })
    this.environment.hot.on('vite:client:disconnect', (_payload, client) => {
      const clientId = this.clients.delete(client)
      if (clientId) {
        this.devEngine.removeClient(clientId)
        this.reloadNeededClientIds.delete(clientId)
      }
    })
    this.environment.hot.on(
      'vite:bundled-dev:reload-needed',
      (payload, client) => {
        const clientId = this.clients.getId(client)
        if (!clientId) return
        debug?.(
          `TRIGGER: client ${clientId} requested a page reload (${payload.reason})`,
        )
        this.environment.logger.info(
          colors.green(`bundling for page reload `) +
            colors.dim(payload.reason),
          { clear: true, timestamp: true },
        )
        this.reloadNeededClientIds.add(clientId)
        this.ensureOutputAndFlushReloadNeeded()
      },
    )

    this._devEngine = await dev(rolldownOptions, outputOptions, {
      onHmrUpdates: (result) => {
        if (result instanceof Error) {
          this.environment.logger.error(
            colors.red(`✘ Build error: ${result.message}`),
            {
              error: result,
            },
          )
          // TODO: send to the specific client
          for (const client of this.clients.getAll()) {
            client.send({
              type: 'error',
              err: prepareError(result),
            })
          }
          return
        }
        const { updates, changedFiles } = result
        if (changedFiles.length === 0) {
          return
        }
        if (updates.every((update) => update.update.type === 'Noop')) {
          debug?.(`ignored file change for ${changedFiles.join(', ')}`)
          return
        }
        for (const { clientId, update } of updates) {
          const client = this.clients.get(clientId)
          if (client) {
            this.handleHmrOutput(client, changedFiles, update)
          }
        }
        // an edit requested a reload but its rebuild failed, leaving the page
        // waiting behind the error overlay. The fix produced this successful
        // build — regenerate output now, or the page would never reload.
        if (this.reloadNeededClientIds.size) {
          this.ensureOutputAndFlushReloadNeeded()
        }
      },
      onOutput: (result) => {
        if (result instanceof Error) {
          this.environment.logger.error(
            colors.red(`✘ Build error: ${result.message}`),
            {
              error: result,
            },
          )
          this.lastBuildError = result
          this.fullReloadPending = false
          this.environment.hot.send({
            type: 'error',
            err: prepareError(result),
          })
          return
        }
        this.lastBuildError = null

        this.storeOutputFiles(result.output)

        // Trigger a full reload if there's no error in the result and a reload is pending from HMR.
        if (this.fullReloadPending) {
          this.fullReloadPending = false
          this.debouncedFullReload()
        }
        if (this.reloadNeededClientIds.size) {
          this.debouncedReloadNeededFlush()
        }
      },
      onAdditionalAssets: (result) => {
        this.storeOutputFiles(result.output)
      },
      watch: {
        skipWrite: true,
        ...convertToDevWatchOptions(this.environment.config.server.watch),
      },
    })
    debug?.('INITIAL: setup dev engine')
    this.devEngine.run().then(
      () => {
        debug?.('INITIAL: run done')
      },
      (e) => {
        debug?.('INITIAL: run error', e)
      },
    )
    this.viteRuntime = await getHmrImplementation(
      this.environment.getTopLevelConfig(),
    )
    this.storeOutputFiles([])
    this.waitForInitialBuildFinish().then(() => {
      if (this._closed) return
      debug?.('INITIAL: build done')
      this.initialBuildCompleted = true
      if (!this.lastBuildError) {
        this.environment.hot.send({
          type: 'full-reload',
          path: '*',
          ifFallback: true,
        })
      }
    })
  }

  private async waitForInitialBuildFinish(): Promise<void> {
    if (this._closed) return
    await this.devEngine.ensureCurrentBuildFinish()
    if (this._closed) return

    let state = await this.devEngine.getBundleState()
    while (!this.hasBuildOutput && !state.lastBuildErrored) {
      await setTimeout(10)
      if (this._closed) return
      await this.devEngine.ensureCurrentBuildFinish()
      if (this._closed) return
      state = await this.devEngine.getBundleState()
    }
  }

  private ensureOutputAndFlushReloadNeeded(): void {
    this.devEngine.ensureLatestBuildOutput().then(
      () => this.debouncedReloadNeededFlush(),
      () => {},
    )
  }

  async triggerBundleRegenerationIfStale(): Promise<boolean> {
    const bundleState = await this.devEngine.getBundleState()

    // Trigger full build if the HMR errors,
    // this is to make it easier to recover if the HMR generation is broken for some reason.
    if (
      this.initialBuildCompleted &&
      bundleState.lastBuildErrored &&
      bundleState.lastErrorStage === 'Hmr'
    ) {
      debug?.(`TRIGGER: access after HMR-stage failure, forcing full rebuild`)

      this.devEngine.triggerFullBuild()
      this.devEngine.ensureLatestBuildOutput().then(() => {
        this.debouncedFullReload()
      })
      return true
    }

    const shouldTrigger =
      bundleState.hasStaleOutput &&
      !bundleState.lastBuildErrored &&
      this.initialBuildCompleted
    if (shouldTrigger) {
      this.devEngine.ensureLatestBuildOutput().then(() => {
        this.debouncedFullReload()
      })
      debug?.(`TRIGGER: access to stale bundle, triggered bundle re-generation`)
    }
    return shouldTrigger
  }

  async triggerLazyBundling(
    moduleId: string | null,
    clientId: string | null,
  ): Promise<{ code: string; filename: string } | undefined> {
    if (!moduleId || !clientId) {
      return
    }
    debug?.(
      `TRIGGER-LAZY: trigger lazy bundling for module ${moduleId} for client ${clientId}`,
    )
    const result = await this.devEngine.compileEntry(moduleId, clientId)
    this.pendingPayloadFilenames.add(result.filename)
    return result
  }

  /**
   * Called by the serving middlewares when the response for a payload completed.
   * Only delivered payloads are recorded on the server's per-client ship map, so
   * later chunks may omit a module only if the payload carrying it was delivered.
   *
   * Note: the payload filename is unique across all clients.
   */
  markPayloadDelivered(filename: string): void {
    if (this.pendingPayloadFilenames.delete(filename)) {
      this.devEngine.notifyPayloadDelivered(filename)
    }
  }

  async close(): Promise<void> {
    this._closed = true
    this.memoryFiles.clear()
    await this._devEngine?.close()
    this.initialBuildCompleted = false
  }

  private storeOutputFiles(output: RolldownOutput['output'][number][]): void {
    // NOTE: don't clear memoryFiles here as incremental build reuses the files
    if (this.viteRuntime) {
      this.memoryFiles.set(BUNDLED_DEV_CLIENT_FILENAME, {
        source: this.viteRuntime,
        etag: getEtag(Buffer.from(this.viteRuntime), { weak: true }),
      })
    }
    for (const outputFile of output) {
      this.memoryFiles.set(outputFile.fileName, () => {
        const source =
          outputFile.type === 'chunk' ? outputFile.code : outputFile.source
        return {
          source,
          etag: getEtag(Buffer.from(source), { weak: true }),
        }
      })
    }
  }

  private async getRolldownOptions() {
    const chunkMetadataMap = new ChunkMetadataMap()
    const rolldownOptions = resolveRolldownOptions(
      this.environment,
      chunkMetadataMap,
    )
    rolldownOptions.experimental ??= {}
    rolldownOptions.experimental.devMode = {
      lazy: true,
      ...(typeof rolldownOptions.experimental.devMode === 'object'
        ? rolldownOptions.experimental.devMode
        : {}),
      implement: '',
      skipCommonRuntimeInjection: true,
    }

    // disable inlineConst optimization due to a bug in Rolldown
    // https://github.com/vitejs/vite/issues/21843
    rolldownOptions.optimization ??= {}
    rolldownOptions.optimization.inlineConst = false

    // set filenames to make output paths predictable so that `renderChunk` hook does not need to be used
    if (Array.isArray(rolldownOptions.output)) {
      for (const output of rolldownOptions.output) {
        output.entryFileNames = 'assets/[name].js'
        output.chunkFileNames = 'assets/[name]-[hash].js'
        output.assetFileNames = 'assets/[name]-[hash][extname]'
        output.minify = false
        output.sourcemap = true
      }
    } else {
      rolldownOptions.output ??= {}
      rolldownOptions.output.entryFileNames = 'assets/[name].js'
      rolldownOptions.output.chunkFileNames = 'assets/[name]-[hash].js'
      rolldownOptions.output.assetFileNames = 'assets/[name]-[hash][extname]'
      rolldownOptions.output.minify = false
      rolldownOptions.output.sourcemap = true
    }

    return rolldownOptions
  }

  private handleHmrOutput(
    client: NormalizedHotChannelClient,
    files: string[],
    hmrOutput: HmrOutput,
  ) {
    if (hmrOutput.type === 'Noop') return

    const shortFile = files
      .map((file) => getShortName(file, this.environment.config.root))
      .join(', ')
    if (hmrOutput.type === 'FullReload') {
      const reason = hmrOutput.reason
        ? colors.dim(` (${hmrOutput.reason})`)
        : ''
      this.environment.logger.info(
        colors.green(`trigger page reload `) + colors.dim(shortFile) + reason,
        { clear: true, timestamp: true },
      )
      // `import.meta.hot.invalidate()` is fully client-side now, so every server-sent
      // reload comes from a file change: defer it until the `onOutput` callback to
      // avoid error overlay flashes.
      this.fullReloadPending = true
      return
    }

    debug?.(`handle hmr output for ${shortFile}`, {
      ...hmrOutput,
      code: typeof hmrOutput.code === 'string' ? '[code]' : hmrOutput.code,
    })

    this.pendingPayloadFilenames.add(hmrOutput.filename)
    this.memoryFiles.set(hmrOutput.filename, {
      // ensure that the generated hmr patch contains ESM syntax
      // this is to avoid attacks like GHSA-4v9v-hfq4-rm2v
      // https://github.com/webpack/webpack-dev-server/security/advisories/GHSA-4v9v-hfq4-rm2v
      // https://green.sapphi.red/blog/local-server-security-best-practices#_2-using-xssi-and-modifying-the-prototype
      // https://green.sapphi.red/blog/local-server-security-best-practices#properly-check-the-request-origin
      // we can also use `Cross-Origin Resource Policy` header instead of this
      // but we cannot use `Sec-Fetch-*` headers as they are only sent to potentially-trustworthy origins
      source: hmrOutput.code + '\n; export {}',
    })
    if (hmrOutput.sourcemapFilename && hmrOutput.sourcemap) {
      this.memoryFiles.set(hmrOutput.sourcemapFilename, {
        source: hmrOutput.sourcemap,
      })
    }
    client.send({
      type: 'bundled-dev-update',
      changedIds: hmrOutput.changedIds,
      url: hmrOutput.filename,
      seq: hmrOutput.seq,
    })
    const { formatted, truncated } = formatAndTruncateFileList(
      hmrOutput.changedIds,
    )
    if (truncated) debugHmr?.(`hmr update ${hmrOutput.changedIds.join(', ')}`)
    this.environment.logger.info(
      colors.green(`hmr update `) + colors.dim(formatted),
      {
        clear: true,
        timestamp: true,
      },
    )
  }
}

class Clients {
  private clientToId = new Map<NormalizedHotChannelClient, string>()
  private idToClient = new Map<string, NormalizedHotChannelClient>()

  setupIfNeeded(client: NormalizedHotChannelClient, clientId: string) {
    const id = this.clientToId.get(client)
    if (id && id !== clientId) {
      throw new Error(
        'client ID conflict detected. Please restart the dev server.',
      )
    }
    this.clientToId.set(client, clientId)
    this.idToClient.set(clientId, client)
  }

  get(id: string): NormalizedHotChannelClient | undefined {
    return this.idToClient.get(id)
  }

  getId(client: NormalizedHotChannelClient): string | undefined {
    return this.clientToId.get(client)
  }

  getAll(): NormalizedHotChannelClient[] {
    return Array.from(this.idToClient.values())
  }

  delete(client: NormalizedHotChannelClient): string | undefined {
    const id = this.clientToId.get(client)
    if (id) {
      this.clientToId.delete(client)
      this.idToClient.delete(id)
      return id
    }
  }
}

function debounce(time: number, cb: () => void) {
  let timer: ReturnType<typeof globalThis.setTimeout> | null
  return () => {
    if (timer) {
      globalThis.clearTimeout(timer)
      timer = null
    }
    timer = globalThis.setTimeout(cb, time)
  }
}
