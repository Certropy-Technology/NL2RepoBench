import os, sys, shutil
import subprocess
import sysconfig
import textwrap
from pathlib import Path
from testing.udir import udir
from testing.support import create_bridged_venv
import pytest

if sys.platform == 'win32':
    pytestmark = pytest.mark.skip('snippets do not run on win32')
try:
    import setuptools
except ImportError:
    pytestmark = pytest.mark.skip('the snippets need setuptools at build time')

def create_venv(name):
    tmpdir = udir / name
    create_bridged_venv(tmpdir)
    return tmpdir, ''

SNIPPET_DIR = Path(__file__).absolute().parent / 'snippets'

def really_run_setup_and_program(dirname, venv_dir_and_paths, python_snippet):
    venv_dir, paths = venv_dir_and_paths
    def remove(dir):
        dir = str(SNIPPET_DIR / dirname / dir)
        shutil.rmtree(dir, ignore_errors=True)
    remove('build')
    remove('__pycache__')
    for basedir in (SNIPPET_DIR / dirname).iterdir():
        remove(basedir / '__pycache__')
    olddir = os.getcwd()
    python_f = udir / 'x.py'
    python_f.write_text(textwrap.dedent(python_snippet))
    try:
        os.chdir(str(SNIPPET_DIR / dirname))
        if os.name == 'nt':
            bindir = 'Scripts'
        else:
            bindir = 'bin'
        vp = str(venv_dir / bindir / 'python')
        env = os.environ.copy()
        env['PYTHONPATH'] = paths
        subprocess.check_call((vp, 'setup.py', 'clean'), env=env)
        # there's a setuptools/easy_install bug that causes this to fail when the build/install occur together and
        # we're in the same directory with the build (it tries to look up dependencies for itself on PyPI);
        # subsequent runs will succeed because this test doesn't properly clean up the build- use pip for now.
        subprocess.check_call((vp, '-m', 'pip', 'install', '.', '--no-build-isolation'), env=env)
        subprocess.check_call((vp, str(python_f)), env=env)
    finally:
        os.chdir(olddir)

def run_setup_and_program(dirname, python_snippet):
    venv_dir = create_venv(dirname + '-cpy')
    really_run_setup_and_program(dirname, venv_dir, python_snippet)
    #
    sys._force_generic_engine_ = True
    try:
        venv_dir = create_venv(dirname + '-gen')
        really_run_setup_and_program(dirname, venv_dir, python_snippet)
    finally:
        del sys._force_generic_engine_
    # the two files lextab.py and yacctab.py are created by not-correctly-
    # installed versions of pycparser.
    assert not (SNIPPET_DIR / dirname / 'lextab.py').exists()
    assert not (SNIPPET_DIR / dirname / 'yacctab.py').exists()

@pytest.mark.thread_unsafe(reason="very slow in parallel")
class TestZIntegration:
    def teardown_class(self):
        if udir.is_dir():
            shutil.rmtree(udir)
        udir.mkdir()

    def test_infrastructure(self):
        run_setup_and_program('infrastructure', '''
        import snip_infrastructure
        assert snip_infrastructure.func() == 42
        ''')

    def test_distutils_module(self):
        run_setup_and_program("distutils_module", '''
        import snip_basic_verify
        p = snip_basic_verify.C.getpwuid(0)
        assert snip_basic_verify.ffi.string(p.pw_name) == b"root"
        ''')

    def test_distutils_package_1(self):
        run_setup_and_program("distutils_package_1", '''
        import snip_basic_verify1
        p = snip_basic_verify1.C.getpwuid(0)
        assert snip_basic_verify1.ffi.string(p.pw_name) == b"root"
        ''')

    def test_distutils_package_2(self):
        run_setup_and_program("distutils_package_2", '''
        import snip_basic_verify2
        p = snip_basic_verify2.C.getpwuid(0)
        assert snip_basic_verify2.ffi.string(p.pw_name) == b"root"
        ''')

    def test_setuptools_module(self):
        run_setup_and_program("setuptools_module", '''
        import snip_setuptools_verify
        p = snip_setuptools_verify.C.getpwuid(0)
        assert snip_setuptools_verify.ffi.string(p.pw_name) == b"root"
        ''')

    def test_setuptools_package_1(self):
        run_setup_and_program("setuptools_package_1", '''
        import snip_setuptools_verify1
        p = snip_setuptools_verify1.C.getpwuid(0)
        assert snip_setuptools_verify1.ffi.string(p.pw_name) == b"root"
        ''')

    def test_setuptools_package_2(self):
        run_setup_and_program("setuptools_package_2", '''
        import snip_setuptools_verify2
        p = snip_setuptools_verify2.C.getpwuid(0)
        assert snip_setuptools_verify2.ffi.string(p.pw_name) == b"root"
        ''')

    def test_set_py_limited_api(self):
        from cffi.setuptools_ext import _set_py_limited_api
        try:
            import setuptools
        except ImportError as e:
            pytest.skip(str(e))
        orig_version = setuptools.__version__
        # free-threaded Python does not yet support limited API
        expecting_limited_api = (
            not hasattr(sys, 'gettotalrefcount') and not
            (sysconfig.get_config_var("Py_GIL_DISABLED") and sys.version_info < (3, 15))
        )
        try:
            setuptools.__version__ = '26.0.0'
            from setuptools import Extension

            kwds = _set_py_limited_api(Extension, {})
            assert kwds.get('py_limited_api', False) == expecting_limited_api

            setuptools.__version__ = '25.0'
            kwds = _set_py_limited_api(Extension, {})
            assert kwds.get('py_limited_api', False) == False

            setuptools.__version__ = 'development'
            kwds = _set_py_limited_api(Extension, {})
            assert kwds.get('py_limited_api', False) == expecting_limited_api

        finally:
            setuptools.__version__ = orig_version
