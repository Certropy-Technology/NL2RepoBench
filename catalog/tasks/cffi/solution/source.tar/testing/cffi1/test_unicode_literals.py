from _cffi_backend import FFI


def test_cast():
    ffi = FFI()
    assert int(ffi.cast("int", 3.14)) == 3

def test_new():
    ffi = FFI()
    assert ffi.new("int[]", [3, 4, 5])[2] == 5

def test_typeof():
    ffi = FFI()
    tp = ffi.typeof("int[51]")
    assert tp.length == 51

def test_sizeof():
    ffi = FFI()
    assert ffi.sizeof("int[51]") == 51 * 4

def test_alignof():
    ffi = FFI()
    assert ffi.alignof("int[51]") == 4

def test_getctype():
    ffi = FFI()
    assert ffi.getctype("int**") == "int * *"
    assert type(ffi.getctype("int**")) is str

def test_callback():
    ffi = FFI()
    cb = ffi.callback("int(int)", lambda x: x + 42)
    assert cb(5) == 47
