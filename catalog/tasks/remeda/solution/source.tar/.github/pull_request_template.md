> Replace this quote with a description of your changes

---

Make sure that you:

- [ ] Typedoc added for new methods and updated for changed
- [ ] Tests added for new methods and updated for changed
- [ ] New methods added to `src/index.ts`
- [ ] New methods added to `docs/src/content/mapping` for both Lodash and Ramda.

---

<details><summary>We use semantic PR titles to automate the release process!</summary>

https://conventionalcommits.org

PRs should be titled following using the format: `< TYPE >(< scope >)?: description`

### Available Types:

- `feat`: new functions or expanded, backwards compatible, capabilities on existing functions.
- `fix`: changes to the runtime behavior of an existing function, or refinements to its type.
- `docs`: changes to the documentation of a function **or the documentation site**.
- `chore`: anything else that isn't noticeable to library users. This includes test-only changes.

For scope put the name of the function you are working on (either new or
existing).

</details>
