import mdx from "@astrojs/mdx";
import react from "@astrojs/react";
import sitemap from "@astrojs/sitemap";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig, fontProviders } from "astro/config";
import fs from "node:fs/promises";
import path from "node:path";
import { endsWith, filter, pipe, pullObject } from "remeda";
import {
  build,
  defineConfig as defineViteConfig,
  type PluginOption,
} from "vite";
import { SHIKI_THEME } from "./src/lib/shiki";

export default defineConfig({
  site: "https://remedajs.com",

  // The default ("jsx") strips the whitespace that Prettier creates when it
  // wraps an inline element onto its own line mid-sentence, visibly gluing
  // words together in prose.
  compressHTML: true,

  integrations: [react(), mdx(), sitemap()],

  markdown: {
    shikiConfig: {
      theme: SHIKI_THEME,
    },
  },

  fonts: [
    {
      provider: fontProviders.fontsource(),
      name: "Inter",
      cssVariable: "--font-inter",
    },
    {
      // Headings only; the brand wordmark is also Sora. Body stays Inter.
      provider: fontProviders.fontsource(),
      name: "Sora",
      cssVariable: "--font-sora",
      // h3/h4 (600), h2 (700), h1 (800) per the typography scale; no italics.
      weights: [600, 700, 800],
      styles: ["normal"],
      subsets: ["latin"],
      fallbacks: ["sans-serif"],
    },
  ],

  vite: {
    plugins: [
      tailwindcss(),
      staticScriptsPlugin({
        inputDir: "src/scripts",
        outputDir: "public/dist/scripts",
      }),
    ],
  },

  redirects: {
    // TODO: Eventually this could be removed...
    "/v1": "/migrate/v1",
  },
});

/**
 * A simple plugin to run a *separate* build via Vite for static scripts that
 * need to be included by name and loaded by the browser directly.
 *
 * TODO: Ideally this should be it's own package. Once we move to a mono-repo setup we should consider creating a separate package for this so that it could be imported into the config instead of living here!
 */
function staticScriptsPlugin({
  inputDir,
  outputDir,
}: {
  readonly inputDir: string;
  readonly outputDir: string;
}): PluginOption {
  const fullPath = path.resolve(import.meta.dirname, inputDir);

  return {
    name: "static-scripts",

    async buildStart(this) {
      this.debug(`Compiling static scripts to ${outputDir}`);

      const input = pipe(
        await fs.readdir(fullPath),
        filter(endsWith(".ts")),
        pullObject(
          (fileName) => path.basename(fileName, ".ts"),
          (fileName) => path.resolve(fullPath, fileName),
        ),
      );

      for (const path of Object.values(input)) {
        this.info(`Found static script: ${path}`);
      }

      const config = defineViteConfig({
        build: {
          rollupOptions: {
            input,
            output: {
              dir: outputDir,
              entryFileNames: "[name].js",
            },
          },
        },

        // Disable the publicDir for the scripts because we aren't really
        // building a server here and the name clash makes vite unhappy (very
        // unhappy!).
        publicDir: false,
      });

      await build(config);
    },
  };
}
