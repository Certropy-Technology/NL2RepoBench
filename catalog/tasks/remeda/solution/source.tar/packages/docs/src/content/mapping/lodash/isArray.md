---
category: Lang
remeda: isArray
---
