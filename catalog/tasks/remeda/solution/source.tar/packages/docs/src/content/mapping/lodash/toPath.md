---
category: Util
remeda: stringToPath
---
