---
category: Array
remeda: takeLast
---
