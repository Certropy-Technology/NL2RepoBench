---
category: Array
remeda: take
---
