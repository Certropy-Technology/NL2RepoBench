---
category: Type
remeda: isNonNullish
---
