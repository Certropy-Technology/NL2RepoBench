---
category: Logic
remeda: isEmptyish
---
