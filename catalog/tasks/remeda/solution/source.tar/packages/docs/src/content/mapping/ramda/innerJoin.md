---
category: Relation
remeda: intersectionWith
---
