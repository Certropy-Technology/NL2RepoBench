---
category: Math
remeda: mean
---
