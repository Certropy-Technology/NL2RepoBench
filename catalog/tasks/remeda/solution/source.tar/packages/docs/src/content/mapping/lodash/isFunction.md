---
category: Lang
remeda: isFunction
---
