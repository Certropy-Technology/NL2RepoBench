---
category: Object
remeda: reduce
---
