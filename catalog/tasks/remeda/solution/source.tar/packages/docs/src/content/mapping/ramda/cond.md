---
category: Logic
remeda: conditional
---
