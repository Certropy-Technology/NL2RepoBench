---
category: Array
remeda: drop
---
