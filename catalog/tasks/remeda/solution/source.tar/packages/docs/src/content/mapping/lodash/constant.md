---
category: Util
remeda: constant
---
