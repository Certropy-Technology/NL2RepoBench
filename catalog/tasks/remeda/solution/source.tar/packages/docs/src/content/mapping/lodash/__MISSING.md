TODO: Go over: https://you-dont-need.github.io/You-Dont-Need-Lodash-Underscore/#/

# Array

- fill
- flattenDepth
- indexOf
- initial
- intersectionBy
- lastIndexOf
- pullAt
- remove
- slice
- sortedIndexOf
- sortedLastIndexOf
- sortedUniqBy
- tail
- union
- unionBy
- unionWith
- unzip
- unzipWith
- xor
- xorBy
- xorWith
- zipObjectDeep

# Date

- now

# Function

- A lot...

# Lang

- castArray
- clone
- cloneDeepWith
- cloneWith
- conformsTo
- eq
- gt
- gte
- isArguments
- isArrayBuffer
- isArrayLike
- isArrayLikeObject
- isBuffer
- isElement
- isEqualWith
- isFinite
- isInteger
- isLength
- isMap
- isMatch
- isMatchWith
- isNaN
- isNative
- isNull
- isObject
- isRegExp
- isSafeInteger
- isSet
- isTypedArray
- isUndefined
- isWeakMap
- isWeakSet
- lt
- lte
- toArray
- toFinite
- toInteger
- toLength
- toNumber
- toPlainObject
- toSafeInteger
- toString

# Number

- inRange

# Object

- assignIn
- assignInWith
- assignWith
- at
- create
- defaults
- defaultsDeep
- findKey
- findLastKey
- forIn
- forInRight
- forOwnRight
- functions
- functionsIn
- invertBy
- invoke
- keysIn
- merge
- mergeWith
- result
- setWith
- toPairsIn
- unset
- update
- updateWith

# Seq

- chain
- thru

# Util

- attempt
- bindAll
- conforms
- flowRight
- iteratee
- matches
- matchesProperty
- method
- methodOf
- mixin
- noConflict
- nthArg
- over
- overEvery
- overSome
- property
- propertyOf
- runInContext
- stubArray
- stubFalse
- stubObject
- stubString
- stubTrue
- uniqueId

# String

(None, we're done with String! 🎉)
