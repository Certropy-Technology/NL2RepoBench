---
category: List
remeda: takeLastWhile
---
