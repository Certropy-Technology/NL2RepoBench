---
category: Array
remeda: intersectionWith
---
