import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { switchTheme, type Theme } from "@/lib/theme";
import { MoonIcon, SunIcon } from "lucide-react";
import { useCallback, type ReactNode } from "react";

export function ThemeSwitcher() {
  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <Button size="icon" title="Toggle theme" variant="ghost">
          <SunIcon className="dark:invisible" />
          <MoonIcon className="invisible absolute dark:visible" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuGroup>
          <ThemeItem theme="light" />
          <ThemeItem theme="dark" />
          <ThemeItem theme="system" />
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function ThemeItem({ theme }: { readonly theme: Theme }): ReactNode {
  const handleClick = useCallback(() => {
    switchTheme(theme);
  }, [theme]);

  return (
    <DropdownMenuItem className="capitalize" onClick={handleClick}>
      {theme}
    </DropdownMenuItem>
  );
}
