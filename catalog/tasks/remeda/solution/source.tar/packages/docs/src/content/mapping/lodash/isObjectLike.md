---
category: Lang
remeda: isObjectType
---
