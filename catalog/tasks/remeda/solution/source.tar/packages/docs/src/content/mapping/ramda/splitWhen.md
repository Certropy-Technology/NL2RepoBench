---
category: List
remeda: splitWhen
---
