---
category: List
remeda: fromEntries
---
