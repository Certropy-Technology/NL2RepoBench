import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { MenuIcon } from "lucide-react";
import { useCallback, useState, type ReactNode } from "react";
import { Navbar, type NavbarCategory } from "./navbar";

export function MobileNav({
  entries,
  title,
}: {
  readonly entries: readonly NavbarCategory[];
  readonly title: string | undefined;
}): ReactNode {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavbarSelect = useCallback(() => {
    setIsOpen(false);
  }, []);

  return (
    <Sheet modal={false} open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          className="md:hidden"
          size="icon"
          title="Library navigation menu"
          variant="ghost"
        >
          <MenuIcon />
        </Button>
      </SheetTrigger>
      <SheetContent className="p-6">
        <SheetTitle
          className={cn(
            "text-lg font-bold capitalize",
            title === undefined && "sr-only",
          )}
        >
          {title ?? "Library Entries"}
        </SheetTitle>
        <SheetDescription className="sr-only">
          List of all available functions provided by the library.
        </SheetDescription>
        <Navbar entries={entries} onSelect={handleNavbarSelect} />
      </SheetContent>
    </Sheet>
  );
}
