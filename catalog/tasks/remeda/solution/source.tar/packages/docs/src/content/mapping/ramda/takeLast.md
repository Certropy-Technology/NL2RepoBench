---
category: List
remeda: takeLast
---
