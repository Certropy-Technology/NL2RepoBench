---
category: Lang
remeda: isBoolean
---
