---
category: List
remeda: splitAt
---
