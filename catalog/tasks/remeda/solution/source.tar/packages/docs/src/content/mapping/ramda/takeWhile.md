---
category: List
remeda: takeWhile
---
