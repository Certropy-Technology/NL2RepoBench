---
category: Lang
remeda: isPlainObject
---
