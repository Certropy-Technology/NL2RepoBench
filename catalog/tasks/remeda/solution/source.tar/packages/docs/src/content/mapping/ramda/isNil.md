---
category: Type
remeda: isNullish
---
