---
category: Logic
remeda: allPass
---
