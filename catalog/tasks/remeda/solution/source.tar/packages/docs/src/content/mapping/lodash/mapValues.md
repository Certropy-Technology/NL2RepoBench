---
category: Object
remeda: mapValues
---
