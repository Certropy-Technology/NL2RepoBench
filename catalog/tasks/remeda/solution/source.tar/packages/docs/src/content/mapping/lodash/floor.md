---
category: Math
remeda: floor
---
