---
category: Logic
remeda: anyPass
---
