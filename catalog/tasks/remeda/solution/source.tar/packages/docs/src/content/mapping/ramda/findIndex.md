---
category: List
remeda: findIndex
---
