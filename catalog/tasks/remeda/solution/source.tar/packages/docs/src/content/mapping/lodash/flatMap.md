---
category: Collection
remeda: flatMap
---
