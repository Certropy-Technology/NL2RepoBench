---
category: Array
remeda: takeLastWhile
---
