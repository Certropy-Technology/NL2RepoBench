---
category: List
remeda: dropLast
---
