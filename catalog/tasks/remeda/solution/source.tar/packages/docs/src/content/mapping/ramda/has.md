---
category: Object
remeda: hasProp
---
