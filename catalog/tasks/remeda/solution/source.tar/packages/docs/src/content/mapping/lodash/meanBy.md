---
category: Math
remeda: meanBy
---
