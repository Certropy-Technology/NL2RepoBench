---
category: List
remeda: findLastIndex
---
