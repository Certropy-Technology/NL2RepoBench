import test from 'ava';
import stripAnsi from './index.js';

test('strip color from string', t => {
	t.is(stripAnsi('\u001B[0m\u001B[4m\u001B[42m\u001B[31mfoo\u001B[39m\u001B[49m\u001B[24mfoo\u001B[0m'), 'foofoo');
});

test('strip color from ls command', t => {
	t.is(stripAnsi('\u001B[00;38;5;244m\u001B[m\u001B[00;38;5;33mfoo\u001B[0m'), 'foo');
});

test('strip reset;setfg;setbg;italics;strike;underline sequence from string', t => {
	t.is(stripAnsi('\u001B[0;33;49;3;9;4mbar\u001B[0m'), 'bar');
});

test('strip link from terminal link', t => {
	t.is(stripAnsi('\u001B]8;;https://github.com\u0007click\u001B]8;;\u0007'), 'click');
});

test('strip OSC sequence with BEL terminator', t => {
	const input = '\u001B[2J\u001B[m\u001B[HABC\r\n\u001B]0;C:\\WINDOWS\\system32\\cmd.exe\u0007\u001B[?25h';
	const output = stripAnsi(input);
	t.is(output, 'ABC\r\n');
});

test('strip color from string using 8-bit CSI introducer', t => {
	t.is(stripAnsi('\u009B31mfoo\u009B39m'), 'foo');
});

test('return string as-is if no ANSI codes', t => {
	t.is(stripAnsi('foo bar'), 'foo bar');
});

test('return empty string as-is', t => {
	t.is(stripAnsi(''), '');
});
