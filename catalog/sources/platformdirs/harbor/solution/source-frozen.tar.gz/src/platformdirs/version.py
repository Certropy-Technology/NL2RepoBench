"""Version information."""

from __future__ import annotations

__version__ = "4.11.3"
__version_tuple__ = (4, 11, 3)
